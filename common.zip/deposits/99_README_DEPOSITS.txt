## Possible Deposit Variables ##
# icon												# if not specified, uses gfx/interface/icons/deposits/<key>.dds
# resources											# (colony carrier or astral rift scope)
# potential											# can this deposit type be picked when randomizing? (colony carrier or astral rift scope)
# station											# station class in orbit to gather (only supports orbital station classes:
													# shipclass_mining_station/shipclass_research_station/shipclass_observation_station/shipclass_starbase/none) (default none)
# use_for_min_max_adjustments = yes/no				# if yes, when randomizing deposits, this type may be added or removed to fulfill the requirements of
													# districts' min/max_for_deposits_on_planet and the MIN_UNBLOCKED/BLOCKED_DEPOSITS defines (default no)
# is_for_colonizable = yes/no						# determines whether randomization can select this type for colonizable or non-colonizable objects (default no)
# category											# category from deposit_categories
# custom_tooltip									# loc included in the deposit's tooltip
# custom_tooltip_short								# loc included in the colony carrier and colonization views
# is_null = yes/no									# only needed for the null deposit (default no)

# can_be_cleared_potential							# can this blocker be cleared? If not, hide the clear button (colony carrier scope)
# can_be_cleared									# can this blocker be cleared? (colony carrier scope)
# prerequisites										# technologies required to clear the blocker
# time												# days to clear this blocker (default -1)
# on_cleared										# effect when the blocker is cleared

# blocker_swap_types = {}							# deposit types that can be blocked by this blocker
# all_blocker_swap_types = yes/no					# if yes, pick swap type from all possible non-blocker types (default no). Always uses drop_weight
# use_weights_for_blocker_swap_types = yes/no		# when picking a swap type, use drop_weight if yes and equal probability if no (default no)

# terraforming_swap_types = {}						# deposit types that can replace this one after terraforming if its potential is now false
# should_swap_deposit_on_terraforming = yes/no		# terraforming swap can only happen if this is yes (default no)
# all_terraforming_swap_types = yes/no				# if yes, pick terraforming swap type from all possible non-blocker types (default no). Always uses drop_weight
# use_weights_for_terraforming_swap_types = yes/no	# when picking a terraforming swap type, use drop_weight if yes and equal probability if no (default no)

# planet_modifier									# applied to colony carrier
# habitat_modifier									# applied to habitats in the same system as this planet
# country_modifier									# applied to owning country if the colony is not occupied
# triggered_planet_modifier							# applied to colony carrier (colony carrier scope)
# triggered_planet_pop_group_modifier_for_all		# see documentation in buildings file
# triggered_planet_pop_group_modifier_for_species	# see documentation in buildings file

# drop_weight										# weight when randomizing (colony carrier or astral rift scope) (default 1)
# ai_weight											# AI willingness to clear blocker (country scope). Note: weight 1 is default and is treated specially -
													# it is set to weight 0 if the planet has no need of more max districts or of districts
													# of the type gained from clearing the blocker.