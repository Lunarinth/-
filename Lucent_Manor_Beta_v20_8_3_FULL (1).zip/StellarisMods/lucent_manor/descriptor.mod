version="4.5.2"
tags={
    "Species"
}
name="Lucent Manor Beta"
supported_version="v4.5.*"

dependencies={
	"UI Overhaul Dynamic"
}
