version="4.5.2"
tags={
    "Species"
}
name="Lucent Manor Beta"
supported_version="4.5.2"

dependencies={
	"UI Overhaul Dynamic"
}
