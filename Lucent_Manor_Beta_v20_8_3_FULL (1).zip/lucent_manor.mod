version="4.5.2"
tags={
    "Species"
}
name="Lucent Manor Beta"
supported_version="4.5.2"
path="C:/StellarisMods/lucent_manor"

dependencies={
    "UI Overhaul Dynamic"
}
