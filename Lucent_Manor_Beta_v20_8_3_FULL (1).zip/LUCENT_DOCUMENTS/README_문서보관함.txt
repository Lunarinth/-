LUCENT MANOR - 내장 문서 보관함

이 폴더는 게임 스크립트와 무관한 개발/배포용 TXT 문서를 한곳에 보존하기 위한 전용 폴더입니다.
향후 패치에서는 이 폴더를 삭제하거나 초기화하지 않고 그대로 승계합니다.

01_패치노트
- 현재/과거 Alpha 패치노트
- 이전 배포판에서 회수한 패치노트는 '이전_패치노트_보관'에 저장

02_복구_참고자료
- 초상화 복구 등 작업 참고자료

03_개발_요약
- 향후 시스템/테스트/개발 요약 TXT 저장 위치

주의:
- gfx/portraits/portraits/lucent_portraits.txt 같은 실제 게임 데이터 TXT는 문서가 아니므로 이동하지 않습니다.
- INSTALL_LUCENT_MANOR.bat, descriptor.mod, lucent_manor.mod 역시 설치/게임 로더 파일이므로 이동하지 않습니다.
