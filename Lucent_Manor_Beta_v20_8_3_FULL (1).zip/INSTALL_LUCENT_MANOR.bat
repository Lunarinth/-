@echo off
setlocal EnableExtensions
set "SRC=%~dp0StellarisMods\lucent_manor"
set "DST=C:\StellarisMods\lucent_manor"

for /f "tokens=2,*" %%A in ('reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders" /v Personal 2^>nul ^| find /i "Personal"') do set "DOCS=%%B"
if not defined DOCS set "DOCS=%USERPROFILE%\Documents"
call set "DOCS=%DOCS%"
set "MODROOT=%DOCS%\Paradox Interactive\Stellaris\mod"

echo [1/3] Installing Lucent Manor Beta v20.8
if not exist "C:\StellarisMods" mkdir "C:\StellarisMods"
if exist "%DST%" rmdir /s /q "%DST%"
xcopy "%SRC%" "%DST%\" /E /I /Y >nul
if errorlevel 1 goto fail

echo [2/3] Installing launcher descriptor
if not exist "%MODROOT%" goto modroot_missing
copy /Y "%~dp0lucent_manor.mod" "%MODROOT%\lucent_manor.mod" >nul
if errorlevel 1 goto fail

echo [3/3] Verifying
if exist "%DST%\events\lucent_debug_events.txt" (echo content OK) else (echo content MISSING)
if exist "%DST%\gfx\models\portraits\lucent\lucent_astra.dds" (echo portraits OK) else (echo portraits MISSING)
if exist "%MODROOT%\lucent_manor.mod" (echo descriptor OK) else (echo descriptor MISSING)
echo.
echo DONE.
echo Restart launcher and enable "Lucent Manor".
goto end

:modroot_missing
echo FAILED: Stellaris mod folder was not found.
echo Expected: %MODROOT%
goto end

:fail
echo FAILED during installation.

:end
echo.
pause
